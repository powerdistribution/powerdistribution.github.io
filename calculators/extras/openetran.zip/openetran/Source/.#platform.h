
#ifndef platform_included
#define platform_included



#define FALSE 0
#define TRUE  1


#endif

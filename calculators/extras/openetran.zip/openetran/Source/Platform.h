
#ifndef platform_included
#define platform_included


#if defined(__FreeBSD__)
#define _OS_FREEBSD__
#elif defined(__linux__)
#define _OS_LINUX_
#elif defined(_WIN32) || defined(_WIN64)
#define _OS_WINDOWS_
#elif defined(__APPLE__) && defined(__MACH__)
#define _OS_DARWIN_
#endif


#ifndef _OS_WINDOWS_

#  define FALSE 0
#  define TRUE  1
#  define MB_ICONEXCLAMATION  0
#  define _int32 int
#  define strnicmp strncasecmp
#  define _strnicmp strncasecmp

#else

#  include <wtypes.h>

#endif



#endif
